#include <stdio.h>

int main()
{
    // Print a simple message
    print("Hello World!\r\n");

    return 0;
}
